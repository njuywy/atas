# atas
应用服务器参数自适应调优。

## 依赖
* [Apache Benchmark](http://httpd.apache.org/docs/2.4/programs/ab.html): 负载测试工具。
* [Fuzzylite](https://github.com/fuzzylite/jfuzzylite): 用Java实现的模糊逻辑控制库。

相关说明：
├── AdapTuning.java ----- 自适应参数调优主程序
├── AsAPITest.java  ----- AS参数(最大线程池大小)调优接口
├── FuzzyLogic.java ----- 模糊逻辑控制实现
├── LoadTest.java ------- 基于Apache BenchMark的性能(响应时间)测试工具
└── ParaPair.java ------- 辅助类
