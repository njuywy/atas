package com.atas.app.strategy;

/**
 * Created by cshuo by 2017-03-24
 * 自适应参数调整接口
 */
public interface TuningStrategy {
    // 具体的自适应参数调整方法
    public void adapTuning(int currentMaxThrdSize);
    // 构造调优闭环方法
    public void startIteration(int interval);
}
