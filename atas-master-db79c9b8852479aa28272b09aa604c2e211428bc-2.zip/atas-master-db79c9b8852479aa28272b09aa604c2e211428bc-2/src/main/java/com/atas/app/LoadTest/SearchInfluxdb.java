package com.atas.app.LoadTest;


import org.apache.log4j.PropertyConfigurator;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import java.util.Arrays;
import java.util.List;
import org.apache.log4j.Logger;

/**
 * Created by yeweiyu on 2017/5/13.
 */
public class SearchInfluxdb {



    public static void main(String[] args) {
        final InfluxDB influxDB = InfluxDBFactory.connect("http://localhost:8086", "root", "root");
        final String dbName = "t";
        influxDB.createDatabase(dbName);
    }
}