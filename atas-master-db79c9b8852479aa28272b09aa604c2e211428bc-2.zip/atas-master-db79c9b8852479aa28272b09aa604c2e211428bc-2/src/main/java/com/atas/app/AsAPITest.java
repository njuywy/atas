package com.atas.app;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class AsAPITest {

    private static final String BaseEndpoint = "http://114.212.189.132:8060";
    /**
     * Modify parameters of thread pool
     * @param maxThrdPlSize: 最大线程池大小
     * @param minThrdPlSize: 最小线程池大小
     * @throws IOException
     * @return
     */
    public void setThredPool(int maxThrdPlSize, int minThrdPlSize) throws IOException {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpPost httppost = new HttpPost(BaseEndpoint + "/management/domain/configs/config/server-config/thread-pools/thread-pool/http-thread-pool");

        // thread pool parameters
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("classname", "com.sun.grizzly.http.StatsThreadPool"));
        params.add(new BasicNameValuePair("idleThreadTimeoutSeconds", "900"));
        params.add(new BasicNameValuePair("maxQueueSize", "4096"));
        params.add(new BasicNameValuePair("maxThreadPoolSize", String.valueOf(maxThrdPlSize)));
        params.add(new BasicNameValuePair("minThreadPoolSize", String.valueOf(minThrdPlSize)));
        params.add(new BasicNameValuePair("name", "http-thread-pool"));
        try {
            httppost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        httppost.addHeader("Content-type", "application/x-www-form-urlencoded");
        httppost.addHeader("X-Requested-By", "Loong REST HTML interface");

        //Execute and get the response.
        HttpResponse response = httpclient.execute(httppost);
    }

    public static void main(String []args) throws IOException {
        AsAPITest asApi = new AsAPITest();
        asApi.setThredPool(60,10);
    }
}

