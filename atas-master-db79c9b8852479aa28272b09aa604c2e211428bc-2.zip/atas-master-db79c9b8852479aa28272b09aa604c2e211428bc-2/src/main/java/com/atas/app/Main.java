package com.atas.app;

import com.atas.app.strategy.HillClimbing;
import com.atas.app.strategy.TuningStrategy;
import org.apache.log4j.PropertyConfigurator;

/**
 * Created by cshuo
 * 使用相关策略进行迭代的参数自适应调整, 目前只有基于模糊控制的爬山算法策略.
 */
public class Main {
    private TuningStrategy strategy;

    public Main(TuningStrategy strategy){
        this.strategy = strategy;
    }

    public void startTuning(int interval){
        strategy.startIteration(interval);
    }

    public static void main(String[] args) {
        PropertyConfigurator.configure("log4j.properties");
        int minThrdSize = 10, granularity = 20, localTrystep = 3, iterateInterval = 30;
        double triggerThres = 0.2;
//        String web_service = "http://114.212.189.131:8080/Web/dbaccess";
        String web_service = "http://cshuo.top";

        Main adpt = new Main(new HillClimbing(minThrdSize, granularity, localTrystep, triggerThres, web_service));
        adpt.startTuning(iterateInterval);
    }
}
