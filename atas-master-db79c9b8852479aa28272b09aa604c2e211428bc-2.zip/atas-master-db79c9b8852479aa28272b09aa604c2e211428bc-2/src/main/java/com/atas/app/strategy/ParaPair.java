package com.atas.app.strategy;

/**
 * Created by cshuo on 12/31/16.
 * 辅助类，Pair<最大线程池，响应时间>
 */
public class ParaPair {
    private int maxThdSize;
    private double rt;

    public ParaPair(int maxThdSize, double rt){
        this.maxThdSize = maxThdSize;
        this.rt = rt;
    }

    public int getThdSize(){
        return this.maxThdSize;
    }

    public void setMaxThdSize(int thdSize){
        this.maxThdSize = thdSize;
    }

    public double getRt(){
        return this.rt;
    }

    public void setRt(double rt){
        this.rt = rt;
    }
}
