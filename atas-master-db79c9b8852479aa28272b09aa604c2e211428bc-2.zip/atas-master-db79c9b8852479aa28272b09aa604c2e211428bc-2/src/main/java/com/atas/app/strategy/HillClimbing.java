package com.atas.app.strategy;

import com.atas.app.AsAPITest;
import com.atas.app.LoadTest.InfluxInspect;
import com.atas.app.LoadTest.LoadInspect;
import org.apache.log4j.Logger;

import java.io.IOException;

import static java.lang.Thread.sleep;

/**
 * Created by cshuo, 基于模糊模糊控制实现的爬山算法寻求最优配置，有关设计思想见 文档1-测试报告.
 */
public class HillClimbing implements TuningStrategy {
    private FuzzyLogic fuzzyCtrl;
//    private LoadTest loadTest;
    private LoadInspect loadInspect;
    private AsAPITest asApi;
    private int maxThrdSize;
    private int minThrdSize;
    private int trySteps;
    private int mcGrlty;
    private double triggerThres;
    private int lastTuningTime;
    private String url;
    private static final int reqNum = 5;
    private static Logger logger = Logger.getLogger(HillClimbing.class);

    /**
     * @param minThrdSize: 最小线程池大小
     * @param mcGrlty: 局部求最优时的调整粒度
     * @param trySteps 局部求最优时邻域半径
     * @param url web服务地址
     * @throws IOException
     */
    public HillClimbing(int minThrdSize, int mcGrlty, int trySteps, double triggerThres, String url){
//        this.loadTest = LoadTest.getLD();
        this.loadInspect = InfluxInspect.getInflux();
        this.asApi = new AsAPITest();
        this.fuzzyCtrl = new FuzzyLogic();
        this.fuzzyCtrl.initFC();
        this.minThrdSize = minThrdSize;
        this.trySteps = trySteps;
        this.mcGrlty = mcGrlty;
        this.triggerThres = triggerThres;
        this.url = url;
        this.setMaxThrdSize(minThrdSize*2);
    }

    /**
     * The iterative adaptive tuning of parameters on AS based on Fuzzy logic, using Hill Climbing algorithm (cite: Wiki).
     * 每一轮迭代所做的优化过程，即基于模糊控制的爬山算法实现过程.
     * @return: null
     */
    public void adapTuning(int currentMaxThdSize) {
        double tuningDir = 0.5;  //0.5: ThdSize changing positive, -0.5 for negtive.
        double RtDir;
//        double currentRt = this.loadTest.getRtTp(this.url, this.reqNum)[0];
        double currentRt = this.loadInspect.inspectMetric("atas")[0];
        double preRt = currentRt;
        ParaPair tmpPair;
        int numTries = 0, rtDecSign = 0;

        while(true){
            tmpPair = this.getLocalOptimal(this.mcGrlty, currentMaxThdSize, this.trySteps, tuningDir);
            // terminating condition of adaptive tuning.
//            logger.info("AdapTuning: " + preRt + ", " + currentRt + ", " + tmpPair.getRt());
            if(currentRt < tmpPair.getRt() && currentRt < preRt && numTries > 1) {
                break;
            } else if(numTries > 1 && rtDecSign == 0) {
                // the init parameter is the optimal one.
                break;
            }
            if(tmpPair.getRt() < currentRt){
                preRt = currentRt;
                currentRt = tmpPair.getRt();
                currentMaxThdSize = tmpPair.getThdSize();
                logger.info("MaxThdSize set to: " + currentMaxThdSize);
                try {
                    this.asApi.setThredPool(currentMaxThdSize, this.minThrdSize);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                this.setMaxThrdSize(currentMaxThdSize);
                RtDir = -0.5;
                rtDecSign = 1;
            } else {
                RtDir = 0.5;
            }

            if(this.fuzzyCtrl.getNextMC(tuningDir, RtDir).equals("poslarge")){
                tuningDir = 0.5;
            } else {
                tuningDir = -0.5;
            }
            numTries += 1;
        }
        logger.info("The optimal thdSize is: " + currentMaxThdSize);
    }

    /**
     * @param interval: interval between two iterations.
     */
    public void startIteration(int interval) {
        this.adapTuning(this.minThrdSize*2);
//        double curRt = this.loadTest.getRtTp(this.url, this.reqNum)[0];
        double curRt = this.loadInspect.inspectMetric("atas")[0];
        double ppreRt, preRt = curRt;
        int iterNum = 0;
        while(true){
            logger.info("An iteration starting...");
            ppreRt = preRt;
            preRt = curRt;
//            curRt = this.loadTest.getRtTp(this.url, reqNum)[0];
            curRt = this.loadInspect.inspectMetric("atas")[0];
            logger.info("RT: " + curRt);
            // Both of the last two RTs larger than the ppreRt by 200 or less by 200.
            // 最近两次的性能都比之前的性能下降20%
            if(iterNum > 1 && curRt/ppreRt - 1 > this.triggerThres && preRt/ppreRt - 1 > triggerThres){
                if(curRt - ppreRt > 0 || (curRt - ppreRt < 0 && this.getLastTuningTime() > 3)){
                    logger.warn("(" + ppreRt + "," + preRt + "," + curRt + "). Response Time fluctuation violently!!!");
                    this.adapTuning(this.getMaxThrdSize());
                    this.setLastTuningTime(0);
                }
            }
            this.setLastTuningTime(this.getLastTuningTime() + 1);
            iterNum += 1;
            try {
                sleep(interval * 1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 求局部最优.
     * @param mcGrlty
     * @param currentSize
     * @param trySteps
     * @param tuningDir
     * @return
     * @throws IOException
     */
    public ParaPair getLocalOptimal(int mcGrlty, int currentSize, int trySteps, double tuningDir){
        ParaPair minPair = new ParaPair(0, Double.MAX_VALUE);
        int originSize = currentSize;
        double tmpRt;

        for(int i=0; i< trySteps; i++){
            if(tuningDir > 0){
                currentSize += mcGrlty;
            } else if (currentSize - mcGrlty > this.minThrdSize){
                currentSize -= mcGrlty;
            } else {
                break;
            }
            try {
                this.asApi.setThredPool(currentSize, this.minThrdSize);
            } catch (IOException e) {
                e.printStackTrace();
            }
//            tmpRt = this.loadTest.getRtTp(this.url, this.reqNum)[0];
            tmpRt = this.loadInspect.inspectMetric("atas")[0];
            if(tmpRt < minPair.getRt()){
                minPair.setMaxThdSize(currentSize);
                minPair.setRt(tmpRt);
            }
        }
        try {
            this.asApi.setThredPool(originSize, this.minThrdSize);  //reset the maxThdSize.
        } catch (IOException e) {
            e.printStackTrace();
        }
        logger.info("local optmal: " + minPair.getThdSize() + ", RT: " + minPair.getRt());
        return minPair;
    }

    private int getMaxThrdSize(){
        return this.maxThrdSize;
    }

    private void setMaxThrdSize(int maxThrdSize){
        this.maxThrdSize = maxThrdSize;
    }

    private void setLastTuningTime(int lastTuningTime){
        this.lastTuningTime = lastTuningTime;
    }

    private int getLastTuningTime(){
        return this.lastTuningTime;
    }

    public static void main(String []args){}
}
