package com.atas.app.strategy;

import com.fuzzylite.Engine;
import com.fuzzylite.defuzzifier.Centroid;
import com.fuzzylite.norm.s.Maximum;
import com.fuzzylite.norm.t.Minimum;
import com.fuzzylite.rule.Rule;
import com.fuzzylite.rule.RuleBlock;
import com.fuzzylite.term.Term;
import com.fuzzylite.term.Triangle;
import com.fuzzylite.variable.InputVariable;
import com.fuzzylite.variable.OutputVariable;

/**
 * Created by cshuo on 2016/10/31.
 * 模糊逻辑控制引擎, 模糊控制理论简介见 文档2--模糊控制。
 */
public class FuzzyLogic{
    private Engine engine;

    public FuzzyLogic(){}

    /**
     *  Init fuzzy control engine, include input variables, output variables and rules.
     */
    public void initFC(){
        engine = new Engine();
        engine.setName("AsTuning");

        InputVariable chgMC = new InputVariable();
        chgMC.setEnabled(true);
        chgMC.setName("chgMC");
        chgMC.setRange(-1.000, 1.000);
        chgMC.addTerm(new Triangle("neglarge", -1.0, -0.5, -0.1 ));
        chgMC.addTerm(new Triangle("zero", -0.1, 0, 0.1));
        chgMC.addTerm(new Triangle("poslarge", 0.1, 0.5, 1.0));
        engine.addInputVariable(chgMC);

        InputVariable chgRT = new InputVariable();
        chgRT.setEnabled(true);
        chgRT.setName("chgRT");
        chgRT.setRange(-1.000, 1.000);
        chgRT.addTerm(new Triangle("neglarge", -1.0, -0.5, -0.1 ));
        chgRT.addTerm(new Triangle("zero", -0.1, 0, 0.1));
        chgRT.addTerm(new Triangle("poslarge", 0.1, 0.5, 1.0));
        engine.addInputVariable(chgRT);

        OutputVariable outputVariable = new OutputVariable();
        outputVariable.setEnabled(true);
        outputVariable.setName("nextMC");
        outputVariable.setRange(-1.000, 1.000);
        outputVariable.fuzzyOutput().setAccumulation(new Maximum());
        outputVariable.setDefuzzifier(new Centroid(200));
        outputVariable.setDefaultValue(Double.NaN);
        outputVariable.setLockPreviousOutputValue(false);
        outputVariable.setLockOutputValueInRange(false);
        outputVariable.addTerm(new Triangle("neglarge", -1.0, -0.5, -0.1 ));
        outputVariable.addTerm(new Triangle("zero", -0.1, 0, 0.1));
        outputVariable.addTerm(new Triangle("poslarge", 0.1, 0.5, 1.0));
        engine.addOutputVariable(outputVariable);

        RuleBlock ruleBlock = new RuleBlock();
        ruleBlock.setEnabled(true);
        ruleBlock.setName("");
        ruleBlock.setConjunction(new Minimum());
        ruleBlock.setDisjunction(new Maximum());
        ruleBlock.setActivation(new Minimum());
        ruleBlock.addRule(Rule.parse("if chgMC is neglarge and chgRT is neglarge then nextMC is neglarge", engine));
        ruleBlock.addRule(Rule.parse("if chgMC is neglarge and chgRT is poslarge then nextMC is poslarge", engine));
        ruleBlock.addRule(Rule.parse("if chgMC is poslarge and chgRT is neglarge then nextMC is poslarge", engine));
        ruleBlock.addRule(Rule.parse("if chgMC is poslarge and chgRT is poslarge then nextMC is neglarge", engine));
        ruleBlock.addRule(Rule.parse("if chgMC is poslarge and chgRT is zero then nextMC is zero", engine));
        ruleBlock.addRule(Rule.parse("if chgMC is neglarge and chgRT is zero then nextMC is zero", engine));
        engine.addRuleBlock(ruleBlock);
    }

    /**
     * @param chgMC: input value of change in maxClients.
     * @param chgRT: input value of change in response time
     * @return: next action indicating how to modify the maxClients.
     */
    public String getNextMC(double chgMC, double chgRT){
        OutputVariable ov = engine.getOutputVariable("nextMC");
        double maxActv = -1.0;
        String fuzzyResult = "zero";

        engine.setInputValue("chgMC", chgMC);
        engine.setInputValue("chgRT", chgRT);
        engine.process();

        double tempDeg;
        for(Term term: ov.getTerms()){
            tempDeg = ov.fuzzyOutput().activationDegree(ov.getTerm(term.getName()));
            if (tempDeg > maxActv){
                fuzzyResult = term.getName();
                maxActv = tempDeg;
            }
        }
        return fuzzyResult;
    }

    public static void main(String []args){
        FuzzyLogic fzt = new FuzzyLogic();
        fzt.initFC();

        System.out.println(fzt.getNextMC(-0.5, -0.5));
        System.out.println(fzt.getNextMC(-0.5, 0.5));
        System.out.println(fzt.getNextMC(0.5, -0.5));
        System.out.println(fzt.getNextMC(0.5, 0.5));
        System.out.println(fzt.getNextMC(0.5, 0));
        System.out.println(fzt.getNextMC(-0.5, 0));
    }
}
