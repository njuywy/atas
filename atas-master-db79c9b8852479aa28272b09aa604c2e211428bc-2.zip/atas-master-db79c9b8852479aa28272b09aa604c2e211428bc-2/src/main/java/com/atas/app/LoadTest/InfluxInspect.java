package com.atas.app.LoadTest;

/**
 * Created by cshuo on 17-4-29.
 */
import org.apache.log4j.PropertyConfigurator;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import java.util.Arrays;
import java.util.List;
import org.apache.log4j.Logger;

/**
 * author: cshuo
 * date: 2017/4/29
 * version: 1.0
 * description: get metrics: avg Response Time and Throughput in last 30s,
 * the interval is consistent with configuration in jmeter properties.
 */
public class InfluxInspect implements LoadInspect{
    private static final String DB_URL = "http://114.212.189.132:8086";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";
    private static final String DBNAME = "jmeter";
    private static final String MEASUREMENT = "delta";
    private static InfluxInspect influxInspect;
    private InfluxDB influxDB;
    private Logger logger;

    private InfluxInspect(){
        influxDB = InfluxDBFactory.connect(DB_URL, USERNAME, PASSWORD);
        logger = Logger.getLogger(LoadInspect.class);
    }

    public static InfluxInspect getInflux(){
        if(influxInspect == null){
            influxInspect = new InfluxInspect();
        }
        return influxInspect;
    }

    public void closeInflux(){
        if(influxInspect == null){
            logger.warn("No Influx instance created yet...");
            return;
        }
        influxInspect.influxDB.close();
    }

    /**
     * @return
     * doc: 获取最近30s对并发请求平均响应时间以及吞吐率的统计.
     */
    public double[] inspectMetric(String project){
        double[] rs = new double[2];
        Query query = new Query("select avg, rate from " + MEASUREMENT +
                " where project='"+ project+ "' order by time DESC limit 1", DBNAME);
        QueryResult metrics = influxDB.query(query);
        if(metrics.getResults().get(0).getSeries() == null){
            logger.warn("No available query results....");
            return rs;
        }
        List<List<Object>> values = metrics.getResults().get(0).getSeries().get(0).getValues();
        rs[0] = (Double)values.get(0).get(1);
        rs[1] = (Double)values.get(0).get(2);
        return rs;
    }

    public static void main(String[] args) {
        PropertyConfigurator.configure("log4j.properties");
        InfluxInspect influxInstance = InfluxInspect.getInflux();
        double [] mtcs = influxInstance.inspectMetric("atas");
        influxInstance.logger.info(Arrays.toString(mtcs));
        influxInstance.closeInflux();
    }
}
