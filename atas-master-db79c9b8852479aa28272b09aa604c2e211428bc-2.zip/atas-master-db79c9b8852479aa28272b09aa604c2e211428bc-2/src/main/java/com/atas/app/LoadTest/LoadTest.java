package com.atas.app.LoadTest;

import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;

/**
 * Created by cshuo on 2016/10/31.
 * 基于Apache Benchmark的性能测试工具,包含响应时间(主要)和吞吐率。
 */

public class LoadTest {
    private static LoadTest ld = null;
    private static Logger logger = Logger.getLogger(LoadTest.class);

    public static LoadTest getLD(){
        if (ld == null){
            ld = new LoadTest();
        }
        return ld;
    }

    private LoadTest(){}
    /**
     * @param url: the url of testing applications in AS.
     * @param reqNum: total number of requests.
     * @return: average response time of testing app of num requests.
     */
    public double[] getRtTp(String url, int reqNum){
        double []results = new double[2];
        String extCmd = "ab -n " + String.valueOf(reqNum) + " -c 1 " + url;
        String[] rtStr = executeCommand(extCmd);
        if (rtStr[0] != "" && rtStr[1] != ""){
            String rt = rtStr[1].substring(rtStr[1].indexOf(":") + 1, rtStr[1].indexOf("["));
            results[0] = Double.valueOf(rt);
            String tp = rtStr[0].substring(rtStr[0].indexOf(":") + 1, rtStr[0].indexOf("["));
            results[1] = Double.valueOf(tp);
        }
        return results;
    }

    /**
     * for verifying the validity of the fuzzy control logic in AdapTuning Class.
     * @param maxThrdSize
     * @return
     */
    public double[] getRt(int maxThrdSize){
        double []res = new double[2];
        HashMap<Integer, Double> rtMap = new HashMap<Integer, Double>();
        rtMap.put(20, 100.0);
        rtMap.put(40, 60.0);
        rtMap.put(60, 80.0);
        rtMap.put(80, 50.0);
        rtMap.put(100, 75.0);
        rtMap.put(120, 55.0);
        rtMap.put(140, 80.0);
        rtMap.put(160, 110.0);
        rtMap.put(180, 45.0);
        rtMap.put(200, 65.0);
        rtMap.put(220, 85.0);
        rtMap.put(240, 95.0);
        rtMap.put(260, 105.0);
        res[0] = rtMap.get(maxThrdSize);
        return res;
    }

    /**
     * @param command: the command to be executed.
     * @return: result of executing the command.
     */
    public String[] executeCommand(String command) {
        String []rtStr =  {"", ""};
        Process p;
        try {
            p = Runtime.getRuntime().exec(command);
            p.waitFor();
            BufferedReader reader =  new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = reader.readLine())!= null) {
                if(line.contains("Requests per second:")){
                    rtStr[0] = line;
                } else if(line.contains("Time per request:")){
                    rtStr[1] = line;
                    break;
                }
            }
        } catch (Exception e) {
            logger.error("Apache Bennchmark not found...");
            System.exit(1);
        }
        return rtStr;
    }

    public static void main(String []args){
        LoadTest lt = new LoadTest();
        double [] res = lt.getRtTp("http://114.212.189.131:8080/Web2/dbaccess", 20);
        for(int i=0; i<res.length; i++){
            System.out.println(res[i]);
        }
    }
}
